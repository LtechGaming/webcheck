def commands(inp, allsplit, web):
    if inp == "//test":
        print("Test success" + str(inp) + allsplit[0] + str(web))
def extras(web):
    print(f"The website you chose is {web}")
