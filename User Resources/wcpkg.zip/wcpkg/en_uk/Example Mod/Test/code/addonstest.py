def commands(inp):
    if inp == "//test":
        print("Test success")
def extras(web):
    print(f"The website you chose is {web}")
