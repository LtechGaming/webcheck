def main():
    print("Test success")
