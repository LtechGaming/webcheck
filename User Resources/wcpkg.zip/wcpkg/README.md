This is a WIP project built in python for checking websites to see if they are legit. Be aware that this may not always be accurate, and may flag legit sites, or not flag scam sites.

License: MIT license

Download: http://ltit.mcandrew.me.uk/projects.html or just use this github page
